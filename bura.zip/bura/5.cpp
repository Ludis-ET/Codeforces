#include <iostream>

using namespace std;

int main() {
    int start, end;

    cout << "Enter the starting number: ";
    cin >> start;
    cout << "Enter the ending number: ";
    cin >> end;

    int sum = 0, product = 1;
    int difference = start;
    
    for (int i = start; i <= end; ++i) {
        sum += i;
        product *= i;
        if (i != start) {
            difference -= i;
        }
    }
    
    cout << "Sum: " << sum << endl;
    cout << "Difference: " << difference << endl;
    cout << "Product: " << product << endl;
    return 0;
}
