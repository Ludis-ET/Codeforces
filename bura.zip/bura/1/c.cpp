#include <iostream>

using namespace std;

int main() {
    int n, start;
    cout << "Enter a starting number: ";
    cin >> start;
    cout << "Enter a positive number: ";
    cin >> n;
    for (int i = start; i < start + n; ++i) {
        cout << i << " ";
    }
    return 0;
}
