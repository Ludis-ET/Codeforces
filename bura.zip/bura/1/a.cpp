#include <iostream>

using namespace std;

int main() {
    int n;
    cout << "Enter a positive number: ";
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cout << i << " ";
    }
    return 0;
}
