#include <iostream>

using namespace std;

int main() {
    int n = 10;
    char s = 'a';

    for (int i = 0; i < n; ++i) {
        char c = s + i;

        for (int j = 0; j < i * 2; ++j) {
            cout << " ";
        }

        for (char k = c; k <= s + n - 1; ++k) {
            cout << k << " ";
        }

        cout << endl;
    }

    return 0;
}
