#include <iostream>

using namespace std;

int main() {
    int count = 1;
    char chr = 'a';

    for (int i = 0; i < 6; ++i) {
        for (int j = 0; j <= i; ++j) {
            cout << chr << " ";
            chr++;
        }
        cout << endl;
    }

    return 0;
}
