#include <iostream>

using namespace std;

int main() {
    int n, count = 0;
    cout << "Enter the number of students: ";
    cin >> n;
    for (int i = 0; i < n; ++i) {
        int mark;
        cout << "Enter mark for student " << i + 1 << ": ";
        cin >> mark;
        if (mark > 20) {
            ++count;
        }
    }
    cout << "Number of students scoring more than 20: " << count << endl;
    return 0;
}
