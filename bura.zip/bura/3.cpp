#include <iostream>

using namespace std;

int main() {
    int num;
    do {
        cout << "Enter a number: ";
        cin >> num;
        if (num < 0) {
            cout << "Now you have entered a negative number" << endl;
        }
    } while (num >= 0);
    return 0;
}
