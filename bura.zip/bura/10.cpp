#include <iostream>
#include <limits.h>

using namespace std;

int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;
    int maxNum = INT_MIN, minNum = INT_MAX;
    for (int i = 0; i < n; ++i) {
        int num;
        cout << "Enter number " << i + 1 << ": ";
        cin >> num;
        if (num > maxNum) {
            maxNum = num;
        }
        if (num < minNum) {
            minNum = num;
        }
    }
    cout << "Maximum: " << maxNum << endl;
    cout << "Minimum: " << minNum << endl;
    return 0;
}
